import { Quote } from "lucide-react";

const testimonials = [
  {
    name: "Didier Lavallée",
    role: "CEO AT TETRA TRUST",
    image: "/investor-didier.png",
    quote: "We've found a great partner in Defix-Finance. Their commitment to strong governance and exceptional customer support allows us to operate more efficiently.",
    yearsCollaborating: 4,
    assetsInvested: "$12.5M"
  },
  {
    name: "Marcus Chen",
    role: "MANAGING DIRECTOR, NEXUS CAPITAL",
    image: "/investor-marcus.jpg",
    quote: "Defix-Finance has been instrumental in helping us navigate the complex DeFi landscape. Their platform's reliability gives our investors the confidence they need.",
    yearsCollaborating: 3,
    assetsInvested: "$8.2M"
  },
  {
    name: "Elena Rodriguez",
    role: "HEAD OF DIGITAL ASSETS, VERTEX FUND",
    image: "/investor-elena.jpg",
    quote: "The level of professionalism and technical expertise at Defix-Finance is unmatched. Their support team is always responsive and knowledgeable.",
    yearsCollaborating: 2,
    assetsInvested: "$15.8M"
  }
];

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            See why top investors and institutions choose Defix-Finance for their DeFi solutions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.name}
              className="bg-card/30 border border-border/30 rounded-xl p-5 flex flex-col"
              data-testid={`testimonial-card-${index}`}
            >
              <Quote className="w-8 h-8 text-primary/50 mb-3" />
              
              <p className="text-foreground/90 text-sm leading-relaxed mb-4 flex-1">
                "{testimonial.quote}"
              </p>

              <div className="flex items-center gap-3 mb-4">
                {testimonial.image ? (
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-36 h-36 rounded-xl object-cover object-top border-2 border-primary/30"
                  />
                ) : (
                  <div className="w-36 h-36 rounded-xl bg-primary/20 flex items-center justify-center border-2 border-primary/30">
                    <span className="text-4xl font-bold text-primary">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                )}
                <div>
                  <h4 className="text-foreground font-semibold text-lg">{testimonial.name}</h4>
                  <p className="text-muted-foreground text-sm">{testimonial.role}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border/30">
                <div className="text-center">
                  <p className="text-lg font-bold text-primary">{testimonial.yearsCollaborating}+</p>
                  <p className="text-[10px] text-muted-foreground">Years Collaborating</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-primary">{testimonial.assetsInvested}</p>
                  <p className="text-[10px] text-muted-foreground">Assets Invested</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-4xl font-bold text-primary mb-2">$371M+</p>
            <p className="text-muted-foreground">Total Assets Managed</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-primary mb-2">150+</p>
            <p className="text-muted-foreground">Institutional Partners</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-primary mb-2">5+</p>
            <p className="text-muted-foreground">Years of Operation</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-primary mb-2">99.9%</p>
            <p className="text-muted-foreground">Uptime Guarantee</p>
          </div>
        </div>
      </div>
    </section>
  );
}
