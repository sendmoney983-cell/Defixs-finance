import { Sparkles } from "lucide-react";

const featuredInvestors = [
  { name: "OKX VENTURES", text: "OKX", subtext: "VENTURES" },
  { name: "dao5", text: "dao5" },
  { name: "#HASHED", text: "#HASHED" },
];

const investors = [
  { name: "MECHANISM CAPITAL", text: "MECHANISM", subtext: "CAPITAL" },
  { name: "GEEKCARTEL", icon: "◆" },
  { name: "NOMADCAPITAL", icon: "▲" },
  { name: "COIN98", text: "98" },
  { name: "CETUS", icon: "◗" },
  { name: "MAV", icon: "▲" },
  { name: "ViaBTC", icon: "₿" },
  { name: "ASSEMBLY", icon: "❋" },
  { name: "Gate.io", icon: "◎" },
  { name: "HAILSTONE", icon: "◈" },
];

export function InvestorsSection() {
  return (
    <section className="py-20 bg-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
          <div className="flex items-center gap-2 mb-6 md:mb-0">
            <span className="text-2xl md:text-3xl font-bold text-foreground">Investors</span>
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          
          <div className="flex flex-wrap items-center gap-6 md:gap-10">
            {featuredInvestors.map((investor) => (
              <div 
                key={investor.name}
                className="text-foreground"
                data-testid={`logo-featured-${investor.name.toLowerCase().replace(/\s/g, '-')}`}
              >
                {investor.subtext ? (
                  <div className="flex flex-col items-center leading-tight">
                    <span className="text-xl font-bold tracking-wider">{investor.text}</span>
                    <span className="text-[10px] tracking-[0.3em] text-muted-foreground">{investor.subtext}</span>
                  </div>
                ) : (
                  <span className="text-xl md:text-2xl font-bold italic">{investor.text}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="relative">
        <div className="flex animate-marquee">
          {[...investors, ...investors].map((investor, index) => (
            <div
              key={`${investor.name}-${index}`}
              className="flex-shrink-0 mx-2 bg-card/50 border border-border/50 rounded-xl p-4 min-w-[140px] flex flex-col items-center justify-center gap-2"
              data-testid={`logo-investor-${investor.name.toLowerCase().replace(/\s/g, '-')}-${index}`}
            >
              {investor.icon ? (
                <span className="text-2xl text-primary">{investor.icon}</span>
              ) : investor.text ? (
                <span className="text-2xl font-bold text-foreground">{investor.text}</span>
              ) : null}
              {investor.subtext ? (
                <div className="text-center">
                  <div className="text-xs text-muted-foreground">{investor.subtext}</div>
                </div>
              ) : null}
              <span className="text-xs text-muted-foreground">{investor.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
