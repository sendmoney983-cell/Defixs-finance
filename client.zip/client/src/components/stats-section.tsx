import { Shield } from "lucide-react";

export function StatsSection() {
  return (
    <section className="py-16 bg-background border-t border-border/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8 items-start">
          <div className="space-y-2">
            <h2 className="text-4xl md:text-5xl font-bold text-primary" data-testid="stat-market-size">
              $371.65M
            </h2>
            <p className="text-sm text-muted-foreground">Total Market Size</p>
          </div>

          <div className="space-y-2">
            <h2 className="text-4xl md:text-5xl font-bold text-primary" data-testid="stat-borrowed">
              $128.37M
            </h2>
            <p className="text-sm text-muted-foreground">Total Borrowed</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Shield className="w-4 h-4" />
              <span className="text-sm">Security Audit</span>
            </div>
            <div className="flex flex-wrap gap-4">
              {["OtterSec", "MoveBit", "Veridise", "Salus"].map((auditor) => (
                <div 
                  key={auditor}
                  className="flex items-center gap-2 text-muted-foreground text-sm"
                  data-testid={`auditor-${auditor.toLowerCase()}`}
                >
                  <div className="w-5 h-5 rounded-full bg-muted flex items-center justify-center">
                    <span className="text-xs">{auditor[0]}</span>
                  </div>
                  {auditor}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
