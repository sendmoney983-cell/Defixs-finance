import { SiApple, SiMeta, SiLinkedin } from "react-icons/si";

const backerLogos = [
  { name: "Bank of America", icon: "🏦" },
  { name: "UBS", text: "UBS" },
  { name: "Apple", Icon: SiApple },
  { name: "Meta", Icon: SiMeta },
  { name: "LinkedIn", Icon: SiLinkedin },
];

const teamCards = [
  {
    id: "leadership",
    title: "Experienced Leadership",
    description: "Led by industry veterans with backgrounds spanning world-class finance and technology companies, including Bank of America and Apple."
  },
  {
    id: "track-record",
    title: "Track Record",
    description: "Team of proven builders with a track record of creating multi-billion-dollar TVL DeFi protocols across Solana and BSC."
  },
  {
    id: "security",
    title: "Security & Risk DNA",
    description: "Security-first culture, 24/7 on-call alert system, and in-house risk monitoring frameworks involving liquidation and oracle monitoring."
  }
];

export function TeamSection() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-serif italic text-foreground mb-6">
          Team & Backers
        </h2>
        
        <p className="text-muted-foreground mb-8 max-w-3xl">
          We are committed to building a stable and secure infrastructure, supported by the top names in the industry.
        </p>

        <div className="flex flex-wrap items-center gap-6 md:gap-10 mb-12">
          {backerLogos.map((backer) => (
            <div 
              key={backer.name} 
              className="flex items-center gap-2 text-foreground"
              data-testid={`logo-backer-${backer.name.toLowerCase().replace(/\s/g, '-')}`}
            >
              {backer.Icon ? (
                <backer.Icon className="w-6 h-6 md:w-8 md:h-8" />
              ) : backer.text ? (
                <span className="text-xl md:text-2xl font-bold tracking-tight">{backer.text}</span>
              ) : (
                <span className="text-2xl">{backer.icon}</span>
              )}
              {backer.Icon && <span className="text-lg font-medium hidden md:inline">{backer.name}</span>}
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {teamCards.map((card) => (
            <div
              key={card.id}
              className="bg-card/50 border border-border/50 rounded-xl p-6 hover-elevate"
              data-testid={`card-team-${card.id}`}
            >
              <h3 className="text-lg font-semibold text-foreground mb-3">
                {card.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {card.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
