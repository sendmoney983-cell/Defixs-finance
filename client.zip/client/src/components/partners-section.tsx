const partners = [
  { name: "Ondo", logo: "◎" },
  { name: "Sui Foundation", logo: "◈" },
  { name: "Wormhole", logo: "●" },
  { name: "PYTH", logo: "◉" },
  { name: "OKX WALLET", logo: "◆" },
  { name: "KriyaDEX", logo: "◇" },
  { name: "BlockVision", logo: "◐" },
  { name: "MAVEN", logo: "▲" },
  { name: "Turbos", logo: "◗" },
  { name: "DEEPBOOK", logo: "◎" },
  { name: "Aftermath", logo: "◑" },
  { name: "Bucket", logo: "◒" },
  { name: "TYPUS", logo: "◓" },
];

export function PartnersSection() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-serif text-center text-foreground mb-12">
          Our Partners
        </h2>

        <div className="flex flex-wrap justify-center gap-4">
          {partners.map((partner) => (
            <div
              key={partner.name}
              className="flex items-center gap-2 px-5 py-3 bg-card/30 border border-border/50 rounded-xl hover-elevate min-w-[140px] justify-center"
              data-testid={`logo-partner-${partner.name.toLowerCase().replace(/\s/g, '-')}`}
            >
              <span className="text-lg text-muted-foreground">{partner.logo}</span>
              <span className="text-sm font-medium text-foreground">{partner.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
