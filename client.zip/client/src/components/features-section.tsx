import { useEffect, useRef, useState } from "react";
import { Sparkles } from "lucide-react";

import feature1 from "@assets/feature1.png";
import feature2 from "@assets/feature2_green.png";
import feature3 from "@assets/feature3.png";

const features = [
  {
    id: "liquidity",
    image: feature1,
  },
  {
    id: "security",
    image: feature2,
  },
  {
    id: "innovation",
    image: feature3,
  }
];

export function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      
      const rect = sectionRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      
      const sectionTop = rect.top;
      const sectionHeight = rect.height;
      
      const startPoint = windowHeight;
      const endPoint = -sectionHeight;
      
      const totalDistance = startPoint - endPoint;
      const currentProgress = (startPoint - sectionTop) / totalDistance;
      
      setScrollProgress(Math.max(0, Math.min(1, currentProgress)));
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getCardStyle = (index: number) => {
    const baseRotation = (index - 1) * 15;
    
    const progress = Math.max(0, Math.min(1, scrollProgress * 2 - 0.2));
    
    const rotationY = baseRotation * (1 - progress * 0.5);
    const rotationX = 5 * (1 - progress);
    
    const translateZ = -100 + progress * 100;
    const translateY = (1 - progress) * 50;
    const translateX = (index - 1) * 20 * (1 - progress);
    
    const scale = 0.85 + progress * 0.15;
    const opacity = 0.6 + progress * 0.4;

    return {
      transform: `perspective(1000px) rotateY(${rotationY}deg) rotateX(${rotationX}deg) translateZ(${translateZ}px) translateY(${translateY}px) translateX(${translateX}px) scale(${scale})`,
      opacity,
      transition: 'transform 0.1s ease-out, opacity 0.1s ease-out',
    };
  };

  return (
    <section ref={sectionRef} className="py-24 bg-background min-h-[600px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl md:text-3xl font-bold text-foreground">Features</span>
          <Sparkles className="w-6 h-6 text-yellow-400 fill-yellow-400" />
        </div>
        <p className="text-xl text-muted-foreground italic mb-16">Innovating Beyond Aave</p>

        <div 
          className="flex justify-center items-center gap-4 md:gap-8"
          style={{ perspective: '1000px' }}
        >
          {features.map((feature, index) => (
            <div
              key={feature.id}
              className="w-[200px] md:w-[280px] h-[300px] md:h-[400px] rounded-2xl overflow-hidden border border-primary/30 shadow-lg shadow-primary/10"
              style={getCardStyle(index)}
              data-testid={`card-feature-${feature.id}`}
            >
              <img 
                src={feature.image} 
                alt={`Feature ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
