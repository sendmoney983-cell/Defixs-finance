import { ArrowUpRight } from "lucide-react";
import { SiBitcoin, SiEthereum, SiSolana, SiPolygon, SiBinance, SiChainlink, SiLitecoin, SiDogecoin, SiCardano, SiPolkadot, SiMonero, SiTether } from "react-icons/si";
import emeraldsImage from "@assets/image_1769587486328.png";

const cryptoLogos = [
  { icon: SiBitcoin, name: "Bitcoin", color: "text-orange-500" },
  { icon: SiEthereum, name: "Ethereum", color: "text-blue-400" },
  { icon: SiSolana, name: "Solana", color: "text-purple-400" },
  { icon: SiPolygon, name: "Polygon", color: "text-purple-500" },
  { icon: SiBinance, name: "BNB", color: "text-yellow-400" },
  { icon: SiChainlink, name: "Chainlink", color: "text-blue-500" },
  { icon: SiLitecoin, name: "Litecoin", color: "text-gray-400" },
  { icon: SiDogecoin, name: "Dogecoin", color: "text-yellow-500" },
  { icon: SiCardano, name: "Cardano", color: "text-blue-300" },
  { icon: SiPolkadot, name: "Polkadot", color: "text-pink-500" },
  { icon: SiMonero, name: "Monero", color: "text-orange-400" },
  { icon: SiTether, name: "Tether", color: "text-green-400" },
];

export function AssetsSection() {
  return (
    <section className="relative py-24 bg-black overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <img 
          src={emeraldsImage} 
          alt="" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
      </div>

      <div className="w-full overflow-hidden mb-20">
        <h1 className="text-6xl md:text-7xl font-bold text-foreground tracking-wide whitespace-nowrap animate-marquee-fast">
          DEFIX-FINANCE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DEFIX-FINANCE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DEFIX-FINANCE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DEFIX-FINANCE
        </h1>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              We Support All Major<br />
              Cryptocurrency Wallets
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              DEFIX provides comprehensive support for resolving wallet issues across
              all major blockchain networks and wallet providers.
            </p>

            <div className="space-y-4">
              <a 
                href="#" 
                className="text-primary flex items-center gap-1 hover:underline text-sm"
                data-testid="link-risk-control"
              >
                Secure Wallet Recovery Solutions <ArrowUpRight className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                className="text-primary flex items-center gap-1 hover:underline text-sm"
                data-testid="link-security"
              >
                24/7 Expert Support and Assistance <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {cryptoLogos.map((crypto, index) => (
              <div 
                key={crypto.name}
                className="flex flex-col items-center gap-2 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 hover:border-primary/50 transition-all duration-200 hover-elevate"
                data-testid={`crypto-${crypto.name.toLowerCase()}`}
              >
                <crypto.icon className={`w-8 h-8 ${crypto.color}`} />
                <span className="text-xs text-gray-300 font-medium">{crypto.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
