import { useEffect, useState } from "react";
import { Flag, Rocket, Globe, TrendingUp } from "lucide-react";

const milestones = [
  {
    year: "2023",
    title: "Platform Launch",
    description: "Defix-Finance Founded",
    icon: Rocket,
    delay: 0
  },
  {
    year: "2024",
    title: "Global Expansion",
    description: "100K+ Users Milestone",
    icon: Globe,
    delay: 400
  },
  {
    year: "Q1 2025",
    title: "DeFi Integration",
    description: "Multi-chain Support",
    icon: TrendingUp,
    delay: 800
  },
  {
    year: "Q2 2025",
    title: "Ecosystem Growth",
    description: "Enterprise Solutions",
    icon: Flag,
    delay: 1200
  }
];

export function RoadmapTimeline() {
  const [visibleItems, setVisibleItems] = useState<number[]>([]);

  useEffect(() => {
    milestones.forEach((_, index) => {
      setTimeout(() => {
        setVisibleItems(prev => [...prev, index]);
      }, milestones[index].delay + 500);
    });
  }, []);

  return (
    <div className="relative h-full flex flex-col justify-center py-8">
      <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary/50 to-transparent" />
      
      <div className="space-y-6">
        {milestones.map((milestone, index) => {
          const Icon = milestone.icon;
          const isVisible = visibleItems.includes(index);
          
          return (
            <div
              key={milestone.year}
              className={`relative pl-16 transition-all duration-700 ease-out ${
                isVisible 
                  ? "opacity-100 translate-x-0" 
                  : "opacity-0 translate-x-8"
              }`}
              data-testid={`milestone-${index}`}
            >
              <div className="absolute left-4 w-8 h-8 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center">
                <Icon className="w-4 h-4 text-primary" />
              </div>
              
              <div className="bg-card/30 backdrop-blur-sm border border-border/30 rounded-lg p-3">
                <p className="text-primary font-bold text-lg">{milestone.year}</p>
                <p className="text-foreground font-medium text-sm">{milestone.title}</p>
                <p className="text-muted-foreground text-xs">{milestone.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
