import { useState } from "react";
import { Dialog, DialogContentNoOverlay, DialogTitle } from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { Input } from "@/components/ui/input";
import { Search, Globe } from "lucide-react";
import walletConnectImg from "@assets/image_1769438333308.png";
import trustWalletImg from "@assets/image_1769438276516.png";
import phantomImg from "@assets/image_1769438452510.png";
import rainbowImg from "@assets/image_1769438502399.png";
import coinbaseImg from "@assets/image_1769438642178.png";
import ledgerImg from "@assets/image_1769588801258.png";
import rabbyImg from "@assets/image_1769594692708.png";
import okxImg from "@assets/image_1769439355214.png";
import backpackImg from "@assets/image_1769439556556.png";
import metamaskImg from "@assets/image_1769592924199.png";

interface WalletModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onWalletSelect: (walletName: string, walletId: string) => void;
  disabled?: boolean;
}

const MetaMaskIcon = () => (
  <img src={metamaskImg} alt="MetaMask" className="w-10 h-10 object-contain" />
);

const PhantomIcon = () => (
  <img src={phantomImg} alt="Phantom" className="w-10 h-10 rounded-lg object-cover" />
);

const TrustWalletIcon = () => (
  <img src={trustWalletImg} alt="Trust Wallet" className="w-10 h-10 rounded-lg object-cover" />
);

const WalletConnectIcon = () => (
  <img src={walletConnectImg} alt="WalletConnect" className="w-10 h-10 rounded-lg object-cover" />
);

const RainbowIcon = () => (
  <img src={rainbowImg} alt="Rainbow" className="w-10 h-10 rounded-lg object-cover" />
);

const LedgerIcon = () => (
  <div className="w-10 h-10 rounded-lg bg-black flex items-center justify-center">
    <img src={ledgerImg} alt="Ledger" className="w-8 h-8 object-contain" />
  </div>
);

const BackpackIcon = () => (
  <img src={backpackImg} alt="Backpack" className="w-10 h-10 rounded-lg object-cover" />
);

const OKXIcon = () => (
  <div className="w-10 h-10 rounded-lg bg-black flex items-center justify-center">
    <img src={okxImg} alt="OKX" className="w-8 h-8 object-contain" />
  </div>
);

const CoinbaseIcon = () => (
  <img src={coinbaseImg} alt="Coinbase" className="w-10 h-10 rounded-lg object-cover" />
);

const RabbyIcon = () => (
  <img src={rabbyImg} alt="Rabby" className="w-10 h-10 rounded-lg object-cover" />
);

const wallets = [
  { id: "metamask", name: "MetaMask", recommended: true, icon: MetaMaskIcon },
  { id: "phantom", name: "Phantom", icon: PhantomIcon },
  { id: "trust", name: "Trust Wallet", icon: TrustWalletIcon },
  { id: "walletconnect", name: "WalletConnect", icon: WalletConnectIcon },
  { id: "coinbase", name: "Coinbase Wallet", icon: CoinbaseIcon },
  { id: "rainbow", name: "Rainbow", icon: RainbowIcon },
  { id: "ledger", name: "Ledger", icon: LedgerIcon },
  { id: "rabby", name: "Rabby Wallet", icon: RabbyIcon },
  { id: "backpack", name: "Backpack", icon: BackpackIcon },
  { id: "okx", name: "OKX Wallet", icon: OKXIcon },
  { id: "other", name: "Other Wallet", icon: () => <Globe className="w-10 h-10 text-muted-foreground" /> },
];

export function WalletModal({ open, onOpenChange, onWalletSelect, disabled = false }: WalletModalProps) {
  const [search, setSearch] = useState("");
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);

  const filteredWallets = wallets.filter(w => 
    w.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleWalletClick = (wallet: typeof wallets[0]) => {
    setSelectedWallet(wallet.id);
    setTimeout(() => {
      onWalletSelect(wallet.name, wallet.id);
      setSelectedWallet(null);
    }, 300);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange} modal={!disabled}>
      <DialogContentNoOverlay className={`sm:max-w-[800px] p-0 bg-card border-border overflow-hidden ${disabled ? 'pointer-events-none' : ''}`}>
        <VisuallyHidden>
          <DialogTitle>Connect Wallet</DialogTitle>
        </VisuallyHidden>
        <div className="grid md:grid-cols-2">
          <div className="p-6 border-r border-border/50">
            <div className="flex gap-4 mb-6">
              <button className="px-4 py-2 bg-muted rounded-lg text-sm font-medium text-foreground" data-testid="tab-recent">
                Recent
              </button>
              <button className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground" data-testid="tab-manual">
                Manual Kit
              </button>
            </div>

            <div className="mb-6">
              <p className="text-sm text-muted-foreground mb-3">Popular:</p>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search wallets..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 bg-muted/50 border-border"
                  data-testid="input-search-wallet"
                />
              </div>
            </div>

            <div className="space-y-1 max-h-[350px] overflow-y-auto">
              {filteredWallets.map((wallet) => (
                <button
                  key={wallet.id}
                  onClick={() => handleWalletClick(wallet)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                    selectedWallet === wallet.id 
                      ? "bg-primary/20 border-2 border-primary" 
                      : "hover:bg-muted/50"
                  }`}
                  data-testid={`wallet-${wallet.id}`}
                >
                  <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center p-1">
                    <wallet.icon />
                  </div>
                  <span className="text-foreground font-medium flex-1 text-left">{wallet.name}</span>
                  {wallet.recommended && (
                    <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded font-medium">
                      RECOMMENDED
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full border-2 border-dashed border-muted-foreground/30 flex items-center justify-center mb-6">
              <Globe className="w-8 h-8 text-muted-foreground/50" />
            </div>
            <p className="text-muted-foreground">
              Connect your wallet to get<br />started
            </p>
          </div>
        </div>
      </DialogContentNoOverlay>
    </Dialog>
  );
}
