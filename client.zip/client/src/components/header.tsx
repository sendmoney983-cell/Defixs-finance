import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronDown, Sparkles } from "lucide-react";
import logoImage from "@assets/image_1769436792054.png";

interface HeaderProps {
  onLaunchApp: () => void;
}

const socialLinks = [
  { name: "Discord", href: "#" },
  { name: "Twitter / X", href: "#" },
  { name: "Telegram", href: "#" },
  { name: "Medium", href: "#" },
  { name: "Brand Kit", href: "#" },
];

export function Header({ onLaunchApp }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img src={logoImage} alt="Defix Logo" className="w-10 h-10" />
            <span className="text-lg font-semibold text-foreground" data-testid="text-logo">
              DEFIX-FINANCE
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-1">
            <NavItem label="Aggregator" hasIcon />
            <NavItem label="Ecosystem" />
            <NavItem label="Developers" />
            <SocialsDropdown />
          </nav>

          <Button 
            onClick={onLaunchApp}
            className="bg-card border border-border hover:bg-card/80"
            data-testid="button-launch-app"
          >
            <span className="text-primary mr-1">+</span>
            Launch APP
          </Button>
        </div>
      </div>
    </header>
  );
}

function NavItem({ label, hasIcon }: { label: string; hasIcon?: boolean }) {
  return (
    <button 
      className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
      data-testid={`nav-${label.toLowerCase()}`}
    >
      {hasIcon && <Sparkles className="w-3 h-3 text-primary" />}
      {label}
    </button>
  );
}

function SocialsDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
        onClick={() => setIsOpen(!isOpen)}
        data-testid="nav-socials"
      >
        Socials
        <ChevronDown className={`w-3 h-3 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-40 bg-card border border-border rounded-lg shadow-lg py-2 z-50">
          {socialLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
              data-testid={`dropdown-${link.name.toLowerCase().replace(/\s|\//g, '-')}`}
            >
              {link.name}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
