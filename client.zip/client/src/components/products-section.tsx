import { useState } from "react";
import { Sparkles, ArrowUpRight } from "lucide-react";

const products = [
  {
    id: "lending",
    name: "DEFIX Lending",
    description: "Borrow/Lend top assets in the Move ecosystem with ease. Navigate intuitively and stay informed on position health and rewards. Optimize capital efficiency like a pro.",
    linkText: "Launch Pro"
  },
  {
    id: "volo",
    name: "Volo",
    description: "Liquid staking solution that maximizes your staking rewards while maintaining liquidity. Stake your assets and receive liquid tokens that can be used across DeFi.",
    linkText: "Explore Volo"
  },
  {
    id: "astros",
    name: "Astros",
    description: "Advanced trading platform with perpetual futures and leverage trading. Access deep liquidity and advanced order types for professional trading.",
    linkText: "Trade Now"
  }
];

export function ProductsSection() {
  const [activeProduct, setActiveProduct] = useState("lending");

  const currentProduct = products.find(p => p.id === activeProduct);

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 mb-12">
          <Sparkles className="w-5 h-5 text-yellow-400" />
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">DEFIX Products</h2>
        </div>

        <div className="flex gap-8 mb-8 border-b border-border/30">
          {products.map((product) => (
            <button
              key={product.id}
              onClick={() => setActiveProduct(product.id)}
              className={`pb-4 text-sm font-medium transition-colors relative ${
                activeProduct === product.id 
                  ? "text-foreground" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
              data-testid={`tab-${product.id}`}
            >
              {product.name}
              {activeProduct === product.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="bg-card rounded-xl border border-border overflow-hidden">
              <div className="p-4 border-b border-border/50">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  <div className="w-2 h-2 rounded-full bg-yellow-500" />
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <span className="ml-4 text-xs text-muted-foreground">Lending Market</span>
                </div>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-4 gap-4 text-xs text-muted-foreground">
                  <span>Asset</span>
                  <span>Supply</span>
                  <span>Supply APR</span>
                  <span>Borrow APR</span>
                </div>
                {["USDC", "WETH", "ETH", "SUI", "WBTC"].map((asset, i) => (
                  <div key={asset} className="grid grid-cols-4 gap-4 text-sm items-center py-2 border-b border-border/30 last:border-0">
                    <div className="flex items-center gap-2">
                      <div className={`w-6 h-6 rounded-full ${
                        ["bg-blue-500", "bg-purple-500", "bg-slate-500", "bg-cyan-500", "bg-orange-500"][i]
                      }`} />
                      <span className="text-foreground">{asset}</span>
                    </div>
                    <span className="text-foreground">$5,353.31</span>
                    <span className="text-green-400">{(1.2 + i * 0.5).toFixed(2)}%</span>
                    <span className="text-foreground">{(2.1 + i * 0.3).toFixed(2)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground">
              {currentProduct?.name}
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              {currentProduct?.description}
            </p>
            <button 
              className="text-primary flex items-center gap-1 hover:underline"
              data-testid="button-product-link"
            >
              {currentProduct?.linkText} <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
