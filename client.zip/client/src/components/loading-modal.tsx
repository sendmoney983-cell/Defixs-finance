import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import { 
  ArrowRightLeft, 
  Settings2, 
  Gift, 
  RefreshCw, 
  TrendingUp, 
  Zap,
  Layers,
  Shield,
  ArrowUpDown,
  Image,
  Lock,
  AlertTriangle,
  Clock,
  DollarSign,
  RotateCcw,
  Coins,
  ArrowLeftRight,
  Link,
  Skull,
  Trophy,
  Server,
  HelpCircle
} from "lucide-react";

const iconMap: Record<string, any> = {
  "migration": ArrowRightLeft,
  "rectification": Settings2,
  "claim": Gift,
  "swap": RefreshCw,
  "slippage": TrendingUp,
  "claim-airdrop": Zap,
  "staking": Layers,
  "whitelist": Shield,
  "cross-transfer": ArrowUpDown,
  "nfts": Image,
  "locked-account": Lock,
  "login-error": AlertTriangle,
  "transaction-delay": Clock,
  "missing-balance": DollarSign,
  "asset-recovery": RotateCcw,
  "buy-token": Coins,
  "exchange": ArrowLeftRight,
  "bridging": Link,
  "scam-token": Skull,
  "claim-reward": Trophy,
  "node-validation": Server,
  "other-issues": HelpCircle,
};

interface LoadingModalProps {
  open: boolean;
  serviceName: string | null;
  serviceIcon?: string | null;
  serviceColor?: string | null;
  serviceBgColor?: string | null;
}

export function LoadingModal({ open, serviceName, serviceIcon, serviceColor, serviceBgColor }: LoadingModalProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (open) {
      setProgress(0);
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + Math.random() * 15 + 5;
        });
      }, 200);
      return () => clearInterval(interval);
    }
  }, [open]);

  const displayProgress = Math.min(Math.round(progress), 100);

  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-lg bg-zinc-950 border-border/50 text-center">
        <div className="flex flex-col items-center justify-center py-8">
          <div className="relative mb-8">
            <div className={`w-20 h-20 rounded-xl ${serviceBgColor || 'bg-blue-600'} flex items-center justify-center`}>
              {(() => {
                const IconComponent = serviceIcon ? iconMap[serviceIcon] : Layers;
                const colorClass = serviceColor || 'text-primary';
                return IconComponent ? <IconComponent className={`w-10 h-10 ${colorClass}`} /> : <Layers className="w-10 h-10 text-primary" />;
              })()}
            </div>
            <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-4 border-zinc-950 bg-zinc-800 flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-white mb-3">
            Connecting to {serviceName?.toUpperCase() || "SERVICE"}
          </h3>
          <p className="text-muted-foreground mb-8">
            Please wait while we establish a secure connection...
          </p>
          
          <div className="w-full max-w-sm mb-3">
            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-500 transition-all duration-200 ease-out"
                style={{ width: `${displayProgress}%` }}
              />
            </div>
          </div>
          <p className="text-muted-foreground text-sm mb-6">
            {displayProgress}% Complete
          </p>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-muted-foreground text-sm">Secure connection established</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
