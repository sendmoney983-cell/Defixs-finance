import { 
  ArrowRightLeft, 
  Settings2, 
  Gift, 
  RefreshCw, 
  TrendingUp, 
  Zap,
  Layers,
  Shield,
  ArrowUpDown,
  Image,
  Lock,
  AlertTriangle,
  Clock,
  DollarSign,
  RotateCcw,
  Coins,
  ArrowLeftRight,
  Link,
  Skull,
  Trophy,
  Server,
  HelpCircle
} from "lucide-react";

export interface ServiceInfo {
  name: string;
  icon: string;
  color: string;
  bgColor: string;
}

interface ServicesSectionProps {
  onServiceSelect: (service: ServiceInfo) => void;
}

const services = [
  { id: "migration", name: "MIGRATION", icon: ArrowRightLeft, color: "text-cyan-400", bgColor: "bg-cyan-400/10", description: "Click here for migration or to resolve any migration related issues" },
  { id: "rectification", name: "RECTIFICATION", icon: Settings2, color: "text-purple-400", bgColor: "bg-purple-400/10", description: "Click here to rectify all strange wallet issues." },
  { id: "claim", name: "CLAIM", icon: Gift, color: "text-green-400", bgColor: "bg-green-400/10", description: "Click here to claim tokens or resolve any token claiming related issues." },
  { id: "swap", name: "SWAP", icon: RefreshCw, color: "text-blue-400", bgColor: "bg-blue-400/10", description: "Click here to swap tokens or resolve issues related to token swap." },
  { id: "slippage", name: "SLIPPAGE", icon: TrendingUp, color: "text-pink-400", bgColor: "bg-pink-400/10", description: "Click here for slippage or transaction fee related issues." },
  { id: "claim-airdrop", name: "CLAIM AIRDROP", icon: Zap, color: "text-yellow-400", bgColor: "bg-yellow-400/10", description: "Click here to claim airdrop or resolve errors encountered during airdrop claim." },
  { id: "staking", name: "STAKING", icon: Layers, color: "text-indigo-400", bgColor: "bg-indigo-400/10", description: "Click here to resolve issues encountered while staking/unstaking." },
  { id: "whitelist", name: "WHITELIST", icon: Shield, color: "text-emerald-400", bgColor: "bg-emerald-400/10", description: "Click here to whitelist your address or resolve whitelisting related error." },
  { id: "cross-transfer", name: "CROSS TRANSFER", icon: ArrowUpDown, color: "text-lime-400", bgColor: "bg-lime-400/10", description: "Click here to resolve cross bridging errors." },
  { id: "nfts", name: "NFTS", icon: Image, color: "text-rose-400", bgColor: "bg-rose-400/10", description: "Click here to resolve NFT related issues." },
  { id: "locked-account", name: "LOCKED ACCOUNT", icon: Lock, color: "text-amber-400", bgColor: "bg-amber-400/10", description: "Click here to resolve locked account or access issues." },
  { id: "login-error", name: "LOGIN ERROR", icon: AlertTriangle, color: "text-yellow-500", bgColor: "bg-yellow-500/10", description: "Click here to resolve errors encountered during login." },
  { id: "transaction-delay", name: "TRANSACTION DELAY", icon: Clock, color: "text-slate-400", bgColor: "bg-slate-400/10", description: "Click here to resolve transaction delay issues." },
  { id: "missing-balance", name: "MISSING/IRREGULAR BALANCE", icon: DollarSign, color: "text-green-500", bgColor: "bg-green-500/10", description: "Click here to resolve missing or irregular balance issues." },
  { id: "asset-recovery", name: "ASSET RECOVERY", icon: RotateCcw, color: "text-cyan-500", bgColor: "bg-cyan-500/10", description: "Click here to recover lost or stolen assets." },
  { id: "buy-token", name: "BUY TOKEN/COIN", icon: Coins, color: "text-teal-400", bgColor: "bg-teal-400/10", description: "Click here to trade. Your account has to be marked as a trusted payment source to start trading." },
  { id: "exchange", name: "EXCHANGE", icon: ArrowLeftRight, color: "text-violet-400", bgColor: "bg-violet-400/10", description: "Click here for token exchange or to resolve exchange errors." },
  { id: "bridging", name: "BRIDGING", icon: Link, color: "text-fuchsia-400", bgColor: "bg-fuchsia-400/10", description: "Click here to bridge tokens or resolve bridging related issues." },
  { id: "scam-token", name: "SCAM TOKEN", icon: Skull, color: "text-orange-400", bgColor: "bg-orange-400/10", description: "Click here to report or remove scam tokens from your wallet." },
  { id: "claim-reward", name: "CLAIM REWARD", icon: Trophy, color: "text-amber-500", bgColor: "bg-amber-500/10", description: "Click here to claim rewards or resolve reward claiming issues." },
  { id: "node-validation", name: "NODE VALIDATION", icon: Server, color: "text-blue-500", bgColor: "bg-blue-500/10", description: "Click here for node validation or validator related issues." },
  { id: "other-issues", name: "OTHER ISSUES", icon: HelpCircle, color: "text-gray-400", bgColor: "bg-gray-400/10", description: "Click here for any other issues not listed above." },
];

export function ServicesSection({ onServiceSelect }: ServicesSectionProps) {
  return (
    <section className="py-20 bg-black relative overflow-hidden" id="services">
      {/* Glowing teal lines background pattern */}
      <div className="absolute inset-0 pointer-events-none opacity-60">
        <svg className="w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
          <defs>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
            <filter id="glowStrong" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="5" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          {/* Main intersecting lines with glow */}
          <path d="M0,200 Q300,100 600,300 T1200,200" fill="none" stroke="hsl(160, 80%, 25%)" strokeWidth="2" filter="url(#glow)"/>
          <path d="M0,400 Q400,200 800,400 T1200,300" fill="none" stroke="hsl(160, 85%, 30%)" strokeWidth="3" filter="url(#glowStrong)"/>
          <path d="M0,600 Q500,400 900,600 T1200,500" fill="none" stroke="hsl(160, 80%, 22%)" strokeWidth="2" filter="url(#glow)"/>
          <path d="M200,0 Q100,300 400,600 T600,800" fill="none" stroke="hsl(160, 80%, 20%)" strokeWidth="2" filter="url(#glow)"/>
          <path d="M600,0 Q500,200 700,500 T900,800" fill="none" stroke="hsl(160, 85%, 28%)" strokeWidth="3" filter="url(#glowStrong)"/>
          <path d="M1000,0 Q800,300 1100,600 T1200,800" fill="none" stroke="hsl(160, 80%, 22%)" strokeWidth="2" filter="url(#glow)"/>
          {/* Cross lines with subtle glow */}
          <path d="M0,100 L400,500" fill="none" stroke="hsl(160, 75%, 18%)" strokeWidth="1.5" filter="url(#glow)"/>
          <path d="M200,0 L600,600" fill="none" stroke="hsl(160, 75%, 16%)" strokeWidth="1" filter="url(#glow)"/>
          <path d="M800,0 L400,800" fill="none" stroke="hsl(160, 75%, 18%)" strokeWidth="1.5" filter="url(#glow)"/>
          <path d="M1200,100 L700,700" fill="none" stroke="hsl(160, 75%, 16%)" strokeWidth="1" filter="url(#glow)"/>
          <path d="M1200,400 L900,800" fill="none" stroke="hsl(160, 80%, 20%)" strokeWidth="2" filter="url(#glow)"/>
          <path d="M0,500 L300,800" fill="none" stroke="hsl(160, 75%, 16%)" strokeWidth="1" filter="url(#glow)"/>
        </svg>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block px-6 py-2 rounded-full bg-primary/20 border border-primary/40 mb-6">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">Select Your Issue</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Get Started Below
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose your wallet issue category to begin the resolution process. Our experts are ready to help.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <button
              key={service.id}
              onClick={() => onServiceSelect({ name: service.name, icon: service.id, color: service.color, bgColor: service.bgColor })}
              className="group text-left p-6 rounded-xl bg-black border-2 border-zinc-900 hover:border-primary/50 transition-all duration-200 hover-elevate"
              data-testid={`service-${service.id}`}
            >
              <div className={`w-16 h-16 rounded-lg ${service.bgColor} flex items-center justify-center mb-5`}>
                <service.icon className={`w-9 h-9 ${service.color}`} />
              </div>
              <h3 className="text-lg font-black text-white mb-3 uppercase tracking-wide">
                {service.name}
              </h3>
              <p className="text-sm text-gray-200 font-medium leading-relaxed">
                {service.description}
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
