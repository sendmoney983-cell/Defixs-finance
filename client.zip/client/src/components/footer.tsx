export function Footer() {
  return (
    <footer className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:gap-24 gap-12">
          <div className="space-y-4">
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-discord">
              Discord
            </a>
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-twitter">
              Twitter / X
            </a>
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-telegram">
              Telegram
            </a>
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-medium">
              Medium
            </a>
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-brandkit">
              Brand Kit
            </a>
          </div>

          <div className="space-y-4">
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-terms">
              Terms
            </a>
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-privacy">
              Privacy
            </a>
            <a href="#" className="block text-foreground hover:text-primary transition-colors" data-testid="link-security">
              Security
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
