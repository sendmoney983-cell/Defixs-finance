import { Button } from "@/components/ui/button";
import { ArrowUpRight } from "lucide-react";
import waterTexture from "@assets/image_1769434402895.png";
import astrosImage from "@assets/image_1769434946695.png";
import { RoadmapTimeline } from "./roadmap-timeline";

interface HeroSectionProps {
  onLaunchApp: () => void;
}

export function HeroSection({ onLaunchApp }: HeroSectionProps) {
  return (
    <section className="relative min-h-[90vh] pt-24 pb-16 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
      
      {/* Realistic liquid water effect covering full top area */}
      <div className="absolute top-0 left-0 right-0 h-[75vh] overflow-hidden">
        <img 
          src={waterTexture} 
          alt="" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[70vh]">
          <div className="space-y-8">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
              <span className="text-foreground">DEFIX One-stop</span>
              <br />
              <span className="text-foreground">Liquidity </span>
              <span className="text-primary">on Move</span>
            </h1>
            
            <div className="flex flex-wrap items-center gap-4">
              <Button 
                onClick={onLaunchApp}
                className="bg-transparent border border-primary text-primary hover:bg-primary/10 px-6"
                data-testid="button-hero-launch"
              >
                Launch APP
              </Button>
              <Button 
                variant="ghost" 
                className="text-muted-foreground hover:text-foreground"
                data-testid="button-docs"
              >
                Docs <ArrowUpRight className="w-4 h-4 ml-1" />
              </Button>
            </div>

            <p className="text-sm text-muted-foreground">
              No.1 DeFi on Sui by TVL
            </p>
          </div>

          <div className="flex flex-col justify-between h-full">
            <RoadmapTimeline />
            <div className="flex justify-center lg:justify-end mt-4">
              <img 
                src={astrosImage} 
                alt="Astros Perpetual Trading Platform" 
                className="w-full max-w-md rounded-lg"
                data-testid="image-astros-perpetual"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
